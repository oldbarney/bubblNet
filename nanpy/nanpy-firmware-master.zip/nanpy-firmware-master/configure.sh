#!/bin/bash

cp sample_cfg.h Nanpy/cfg.h
