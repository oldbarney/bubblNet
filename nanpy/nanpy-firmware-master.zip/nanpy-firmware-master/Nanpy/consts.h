#pragma once

#define MAX_READ_BUFFER_SIZE 50

